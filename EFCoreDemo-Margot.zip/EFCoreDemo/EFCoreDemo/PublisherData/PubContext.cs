﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PublisherDomain;
using System.Diagnostics;

namespace PublisherData
{
    public class PubContext : DbContext
    {
        public DbSet<Book> Books { get; set; }

        public DbSet<Author> Authors { get; set; }

        public DbSet<Artist> Artists { get; set; }

        public DbSet<Cover> Covers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDb ; Initial Catalog=PublisherDB;")//;
                                                                                                               // .UseQueryTrackingBehavior (QueryTrackingBehavior.NoTracking);

                //Ecrire les log dans la console :
                //.LogTo(Console.WriteLine);

                // Ecrire les log dans console de débugage :
                .LogTo(message => Debug.WriteLine(message),

                   // filtrer message de log pour garder que ceux de database.command
                   //    .LogTo(Console.WriteLine, new[] {DbLoggerCategory.Database.Command.Name },

                   //voir que les infos de type information :
                   LogLevel.Information);

                // voir les valeurs qui sont cachées par défaut :
                 // .EnableSensitiveDataLogging();
        }

        //Donner des données de démarrage
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>().HasData(
                new Author { Id =2,FirstName = "Jeff", LastName="Olsen"});

            // Renommer colonnes
           // modelBuilder.Entity<Book>().Property(b => b.Title).HasColumnName("Main Title");

            var authors = new Author[]
            {
                new Author { Id =3,FirstName = "Jeff", LastName="Olsssen"},
                new Author { Id =4,FirstName = "Victor", LastName="Hugo"},
                new Author { Id =5,FirstName = "Emile", LastName="Zola"}
            };
            modelBuilder.Entity<Author>().HasData(authors);

            var books = new Book[]
            {
                new Book{BookId = 1, AuthorId = 2, Title="The slight Edge", PublishDate= new DateOnly(1990,1,1), BasePrice=17.50m},
                new Book{BookId = 2, AuthorId = 2, Title="deuxieme livre", PublishDate= new DateOnly(1952,1,1), BasePrice=21.50m},
                new Book{BookId = 3, AuthorId = 3, Title="Blabla", PublishDate= new DateOnly(1990,1,1), BasePrice=17.50m}
            };
            modelBuilder.Entity<Book>().HasData(books);
        }

        // Spécifier relation 1-n lorsque conventions pas respectées :
        //protected override void OnModelCreating (ModelBuilder modelbuilder)
        //{
        //    modelbuilder.Entity<Author>()
        //                .HasMany<Book>()
        //                .WithOne();
        //}


        //Donner nom AuthorFK et pas AuthorID et pour qu'on l'on comprenne que c'est une FK :
        //protected override void OnModelCreating(ModelBuilder modelbuilder)
        //{
        //    modelbuilder.Entity<Author>()
        //                .HasMany<Book>()
        //                .WithOne()
        //                .HasForeignKey(b=>b.AuthorFK);
        //}


        // si on veut pouvoir ajouter élément enfant sans que parents soient associés dès le début (dire que ID peut être nullable):
        //protected override void OnModelCreating(ModelBuilder modelbuilder)
        //{
        //    modelbuilder.Entity<Author>()
        //                .HasMany<Book>()
        //                .WithOne()
        //                .HasForeignKey(b=>b.AuthorFK)     // ou HasForeignKey("AuthorID")
        //                .IsRequired(false);
        //}


        //Journalisation :
        //protected override void OnModelConfiguring(DbContextOptionsBuilder optionBuilder)
        //{
        //    OptionsBuilder
        //        .UseSqlServer("Data Source = (localdb)\\MSSQLLocalDb ; Initial Catalog=PublisherDB;")
        //        .LogTo(Console.WriteLine);
        //}


    }


}
