﻿using System.ComponentModel.DataAnnotations.Schema;

namespace PublisherDomain
{
    public class Book
    {
        public int BookId { get; set; }

        // Renommer la colonnes
        //[Column ("Main Title")]
        public string Title { get; set; }
        public DateOnly PublishDate { get; set; }
        public decimal BasePrice { get; set; }
        public Author Author { get; set; }

        //bcp de dev n'aiment pas faire ça, n'aiment pas mettre la ref à la clef étrangère parmis les attributs de l'entité (donc pas toujours visible) :
        // si on avait pas fait ça, on n'aurait pas pu dans PubContext utiliser "AuthorId" pour def la liste de books
        public int AuthorId { get; set; }

        public Cover Cover { get; set; }

        // si on veut pouvoir ajouter élément enfant sans que parents soient associés dès le début (dire que ID peut être nullable):
        //public int? AuthorId { get; set; }
        public override string ToString()
        {
            return $"Livre : {Title}";
        }
    }
}
