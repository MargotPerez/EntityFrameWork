﻿using Microsoft.EntityFrameworkCore;
using PublisherData;
using PublisherDomain;
//using System.Data.Entity;// pour Include() + installer nuget EntityFramework

//using (PubContext context = new PubContext())
//{
//    context.Database.EnsureCreated();
//}  => on en a plus besoin après 1er lancement car on s'est assuré que db est créée (consomme ressources inutilement si on le garde à chaque fois)


//using var context = new PubContext(); //=> on pourrait mettre ça ici pour ne plus les mettre dans les méthodes à chaque fois; Ca serait pas déconnant ici car on appelle 1 seule méthode à la fois donc pas de demande énormément de ressources
// Bien penser à déclarer ça avant la méthode sinon le context n'est pas instancié


//AddAuthor("Charles", "Duhigg");
//AddAuthor("Victor", "Hugo");
//AddAuthor("Emile", "Zola");
//AddAuthor("Darwin", "Charles");
//AddAuthor("Darwin", "James");
//AddAuthor("De Maupassant", "Guy");
//AddAuthor("De Maupassant", "Nadine");
//AddAuthor("Bonnefoy", "Miguel");
//AddAuthor("Werber", "Bernard");
//AddAuthor("Bourdin", "Françoise");
//AddAuthor("Saviano", "Roberto");
//AddAuthor("Murakami", "Haruki");
//AddAuthor("Aurélie", "Valognes");
//AddAuthor("Grégoire", "Delacourt");
//AddAuthor("Jim", "Harrison");
//AddAuthor("Frank", "Bouysse");

//GetAuthors();

//GetSortedAuthors();

//SkipAndTakeAuthors(3);

//AddAuthorWithBooks();

//AddBookForExistingAuthor();


//GetAuthorsWithBooks();

//EditMultipleAuthorsName("Olsssen","Olson");


//EditMultipleAuthorsNameNoTraking("Olsssen", "Olson");

//DeleteAuthorById(8);


//DeleteAuthorByLastName("Bonnefoy");




// stocker données dans tables
void AddAuthor(string firstName, string lastName)
{
    var author = new Author { FirstName = firstName, LastName = lastName };
    using var context = new PubContext();
    context.Authors.Add(author);
    context.SaveChanges();
}


void AddAuthorWithBooks()
{
    var author = new Author { FirstName = "Pierre", LastName = "Rabhi" };
    author.Books.Add(new Book { Title = "Vers la sobriété heureuse", BasePrice = 12.50m, PublishDate = new DateOnly(2002,1,1)});
    author.Books.Add(new Book { Title = "Solidarité !", BasePrice = 14.50m, PublishDate = new DateOnly(2003, 1, 1) });

    using var context = new PubContext();
    context.Authors.Add(author);
    context.SaveChanges();
}


void AddBookForExistingAuthor()
{
    var book = new Book {Title = "Une nouvelle vie", BasePrice = 23.99m, PublishDate = new DateOnly(2011, 1, 1), AuthorId = 15 };
    
    using var context = new PubContext();
    context.Books.Add(book);
    context.SaveChanges();
}


// lister les auteurs (requête)
void GetAuthors()
{
    using var context = new PubContext();
    var authors = context.Authors.ToList(); // génère une query et en fait une liste et le retourne dans variable authors
    foreach (var item in authors)
    {
        Console.WriteLine($"Auteur {item.Id} :  {item.LastName} {item.FirstName} ");
    }
}




// lister les auteurs triés par Nom puis par prénom(requête)
void GetSortedAuthors()
{
    using var context = new PubContext();
    var authors = context.Authors.OrderBy(a=>a.LastName).ThenBy(a=>a.FirstName).ToList(); 
    foreach (var item in authors)
    {
        Console.WriteLine($"Auteur {item.FirstName} {item.LastName}");
    }
}



void SkipAndTakeAuthors(int numberPerPage)
{

    using var context = new PubContext();
    
    var groupSize = numberPerPage;

    var NbPages = Math.Ceiling((decimal)context.Authors.Count()/ groupSize);
    
    
    for (int i = 0; i < NbPages; i++)
    {
        var authors = context.Authors.Skip(groupSize * i).Take(groupSize).ToList();
        Console.WriteLine($"******* Page {i + 1} **********");
        foreach (var item in authors)
        {
            Console.WriteLine(item); // Cf override ToString() dans classe Author
        }
    }
}


void GetAuthorsWithBooks()
{
    using var context = new PubContext();
    var authorWithBooks = context.Authors.Include(b=> b.Books).ToList();

    foreach (var author in authorWithBooks)
    {
        Console.WriteLine(author);
        foreach (var book in author.Books)
        {
            Console.WriteLine($"\t\t{book.Title}");
        }
    }
}


void EditMultipleAuthorsName(string OldLastName, string NewLastName)
{
    using var context = new PubContext();
    var authorToChange = context.Authors.Where(nom => nom.LastName == OldLastName).ToList();

    foreach (var author in authorToChange)
    {
        author.LastName = NewLastName;
    }


    Console.WriteLine("Avant l'appel de la méthode DetectChanges() : \n" + context.ChangeTracker.DebugView.ShortView);
    context.ChangeTracker.DetectChanges();
    Console.WriteLine("Après l'appel de la méthode DetectChanges() : \n" + context.ChangeTracker.DebugView.ShortView);


    context.SaveChanges();// SaveChanges() fait appel à DetectChanges()
    Console.WriteLine("Après l'appel de la méthode SaveChanges() : \n" + context.ChangeTracker.DebugView.ShortView);

}



void EditMultipleAuthorsNameNoTraking(string OldLastName, string NewLastName)
{
    using var context = new PubContext();
    var authorToChange = context.Authors.AsNoTracking()
        .Where(nom => nom.LastName == OldLastName).ToList();
        //.Where(nom => nom.LastName == OldLastName).AsNoTracking().ToList();
    foreach (var author in authorToChange)
    {
        author.LastName = NewLastName;
      //  context.Update(author);
    }

    

    Console.WriteLine("Avant l'appel de Update() : \n" + context.ChangeTracker.DebugView.ShortView);
    context.Authors.UpdateRange(authorToChange);
    Console.WriteLine("Après l'appel de Update() : \n" + context.ChangeTracker.DebugView.ShortView);
    
    context.SaveChanges();// SaveChanges() fait appel à DetectChanges()
    Console.WriteLine("Après l'appel de la méthode SaveChanges() : \n" + context.ChangeTracker.DebugView.ShortView);

}



void DeleteAuthorById(int iD){
    using var context = new PubContext();

    var authorToDelete = context.Authors.Find(iD);// on pourrait faire avec Where mais c'est plus optimal de faire avec Find
    if (authorToDelete != null) // sert surtout pour l'optimisation car renverrait de toutes façons même resultat
    {
        context.Authors.Remove(authorToDelete);
        context.SaveChanges();
        Console.WriteLine($"{authorToDelete.LastName} avec l'ID {authorToDelete.Id} a été supprimé");
    }
    else
    {
        Console.WriteLine($"L'auteur avec l'ID {iD} n'a pas été trouvé");
    }
    
}




void DeleteAuthorByLastName(string lastName)
{
    using var context = new PubContext();

    var authorToDelete = context.Authors.Where(ln =>ln.LastName == lastName).ToList();

    //foreach (var author in authorToDelete)
    //{
    //    context.Authors.Remove(author); // serait mieux avec Remove Range
    //}

    context.Authors.RemoveRange(authorToDelete); // mieux pour optimisation si plusieurs auteurs qui ont même nom
    context.SaveChanges();
}

